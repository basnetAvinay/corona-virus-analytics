package com.np.avinay.coronavirustracker.model;


public class LocationStats {

    private String state;
    private String country;
    private Integer latestTotalCases;
    private Integer diffTotalFromPrevDay;
    private Integer latestRecoveredCases;
    private Integer diffRecoveredFromPrevDay;
    private Integer latestDeathCases;
    private Integer diffDeathFromPrevDay;

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public Integer getLatestTotalCases() {
        return latestTotalCases;
    }

    public void setLatestTotalCases(Integer latestTotalCases) {
        this.latestTotalCases = latestTotalCases;
    }

    public Integer getDiffTotalFromPrevDay() {
        return diffTotalFromPrevDay;
    }

    public void setDiffTotalFromPrevDay(Integer diffTotalFromPrevDay) {
        this.diffTotalFromPrevDay = diffTotalFromPrevDay;
    }

    public Integer getLatestRecoveredCases() {
        return latestRecoveredCases;
    }

    public void setLatestRecoveredCases(Integer latestRecoveredCases) {
        this.latestRecoveredCases = latestRecoveredCases;
    }

    public Integer getDiffRecoveredFromPrevDay() {
        return diffRecoveredFromPrevDay;
    }

    public void setDiffRecoveredFromPrevDay(Integer diffRecoveredFromPrevDay) {
        this.diffRecoveredFromPrevDay = diffRecoveredFromPrevDay;
    }

    public Integer getLatestDeathCases() {
        return latestDeathCases;
    }

    public void setLatestDeathCases(Integer latestDeathCases) {
        this.latestDeathCases = latestDeathCases;
    }

    public Integer getDiffDeathFromPrevDay() {
        return diffDeathFromPrevDay;
    }

    public void setDiffDeathFromPrevDay(Integer diffDeathFromPrevDay) {
        this.diffDeathFromPrevDay = diffDeathFromPrevDay;
    }

    @Override
    public String toString() {
        return "LocationStats{" +
                "state='" + state + '\'' +
                ", country='" + country + '\'' +
                ", latestTotalCases=" + latestTotalCases +
                '}';
    }
}
