package com.np.avinay.coronavirustracker.services;

import com.np.avinay.coronavirustracker.model.LocationStats;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.io.StringReader;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.List;

@Service
public class CoronaVirusDataService {

    private static String CASES_CONFIRMED_URL = "https://raw.githubusercontent.com/CSSEGISandData/COVID-19/master/csse_covid_19_data/csse_covid_19_time_series/time_series_19-covid-Confirmed.csv";
    private static String DEATH_CONFIRMED_URL = "https://raw.githubusercontent.com/CSSEGISandData/COVID-19/master/csse_covid_19_data/csse_covid_19_time_series/time_series_19-covid-Deaths.csv";
    private static String RECOVERED_CONFIRMED_URL = ""

    private List<LocationStats> allStats = new ArrayList<>();

    public List<LocationStats> getAllStats() {
        return allStats;
    }

    // PostConstruct tells when spring construct instantiate this service class
    // After it is done, execute this method
    // What if this application is served on AWS? run on daily basis
    // use Scheduled
    @PostConstruct
    @Scheduled(cron = "* * 1 * * *")
    public void fetchVirusData() throws IOException, InterruptedException {
        try {
            // We create newStats so that when we're populating and user makes request
            // we can still show the previous all stats
            List<LocationStats> newStats = new ArrayList<>();
            HttpClient client = HttpClient.newHttpClient();

            // We need to convert VIRUS_DATA_URL string to url
            // so we're making a http request of where to fetch the data
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(VIRUS_DATA_URL))
                    .build();

            // Second option is body handler
            // Basically tells what to do with the body
            HttpResponse<String> httpResponse = client.send(request, HttpResponse.BodyHandlers.ofString());
            System.out.println(httpResponse);

            StringReader csvBodyReader = new StringReader(httpResponse.body());
            Iterable<CSVRecord> records = CSVFormat.DEFAULT.withFirstRecordAsHeader().parse(csvBodyReader);

            for (CSVRecord record : records) {
                LocationStats locationStats = new LocationStats();
                locationStats.setState(record.get("Province/State"));
                locationStats.setCountry(record.get("Country/Region"));

                int latestCases = Integer.parseInt(record.get(record.size() - 1));
                int prevDayCases = Integer.parseInt(record.get(record.size() - 2));

                locationStats.setLatestTotalCases(latestCases);
                locationStats.setDiffTotalFromPrevDay(latestCases - prevDayCases);

                System.out.println(locationStats);
                newStats.add(locationStats);
            }
            this.allStats = newStats;
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
